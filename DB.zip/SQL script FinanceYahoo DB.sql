USE [master]
GO
/****** Object:  Database [YahooFinance]    Script Date: 12/18/2023 12:55:41 AM ******/
CREATE DATABASE [YahooFinance]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'YahooFinance', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\YahooFinance.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'YahooFinance_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\YahooFinance_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [YahooFinance] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [YahooFinance].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [YahooFinance] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [YahooFinance] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [YahooFinance] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [YahooFinance] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [YahooFinance] SET ARITHABORT OFF 
GO
ALTER DATABASE [YahooFinance] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [YahooFinance] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [YahooFinance] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [YahooFinance] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [YahooFinance] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [YahooFinance] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [YahooFinance] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [YahooFinance] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [YahooFinance] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [YahooFinance] SET  DISABLE_BROKER 
GO
ALTER DATABASE [YahooFinance] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [YahooFinance] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [YahooFinance] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [YahooFinance] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [YahooFinance] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [YahooFinance] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [YahooFinance] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [YahooFinance] SET RECOVERY FULL 
GO
ALTER DATABASE [YahooFinance] SET  MULTI_USER 
GO
ALTER DATABASE [YahooFinance] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [YahooFinance] SET DB_CHAINING OFF 
GO
ALTER DATABASE [YahooFinance] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [YahooFinance] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [YahooFinance] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [YahooFinance] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'YahooFinance', N'ON'
GO
ALTER DATABASE [YahooFinance] SET QUERY_STORE = OFF
GO
USE [YahooFinance]
GO
/****** Object:  Table [dbo].[HistoryData]    Script Date: 12/18/2023 12:55:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[HistoryData](
	[ID] [uniqueidentifier] NOT NULL,
	[DateCreated] [datetime2](7) NOT NULL,
	[LastResult] [bit] NOT NULL,
	[FullCompanyName] [nvarchar](max) NULL,
	[MarcetCap] [nvarchar](max) NULL,
	[YearFounded] [int] NULL,
	[NumberOfEmployees] [int] NULL,
	[HeadquartersCity] [nvarchar](max) NULL,
	[HeadquartersCountry] [nvarchar](max) NULL,
	[DateOfTheData] [datetime2](7) NULL,
	[ClosePrice] [nvarchar](max) NULL,
	[OpenPrice] [nvarchar](max) NULL,
	[Symbol] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[HistoryData] ADD  DEFAULT (newid()) FOR [ID]
GO
/****** Object:  StoredProcedure [dbo].[InsertHistoryData]    Script Date: 12/18/2023 12:55:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Slobodan Kuzmanović
-- Create date: 17.12.2023.
-- Description:	Insert Data in HistoryData table
-- =============================================
CREATE PROCEDURE [dbo].[InsertHistoryData]
	@FullCompanyName nvarchar(MAX),
	@MarcetCap nvarchar(MAX),
	@YearFounded int = null,
	@NumberOfEmployees int,
	@HeadquartersCity nvarchar(MAX),
	@HeadquartersCountry nvarchar(MAX),
	@DateOfTheData datetime2(7),
	@ClosePrice nvarchar(MAX),
	@OpenPrice nvarchar(MAX),
	@Symbol nvarchar(MAX)
AS
BEGIN


UPDATE [dbo].[HistoryData] set LastResult = 0 where LastResult = 1 AND Symbol = @Symbol


INSERT INTO [dbo].[HistoryData]
           ([DateCreated]
           ,[LastResult]
           ,[FullCompanyName]
           ,[MarcetCap]
           ,[YearFounded]
           ,[NumberOfEmployees]
           ,[HeadquartersCity]
           ,[HeadquartersCountry]
           ,[DateOfTheData]
           ,[ClosePrice]
           ,[OpenPrice]
		   ,[Symbol])
     VALUES
           (GETDATE()
           ,1
           ,@FullCompanyName
           ,@MarcetCap
           ,@YearFounded
           ,@NumberOfEmployees
           ,@HeadquartersCity
           ,@HeadquartersCountry
           ,@DateOfTheData
           ,@ClosePrice
           ,@OpenPrice
		   ,@Symbol)

END
GO
USE [master]
GO
ALTER DATABASE [YahooFinance] SET  READ_WRITE 
GO
